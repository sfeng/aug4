//
//  CoverFlowAppDelegate.h
//  CoverFlow
//
//  Created by Avinash on 4/7/10.
//  Copyright Apple Inc 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CoverFlowViewController;

@interface CoverFlowAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    CoverFlowViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet CoverFlowViewController *viewController;

@end

