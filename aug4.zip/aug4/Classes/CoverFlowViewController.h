//
//  CoverFlowViewController.h
//  CoverFlow
//
//  Created by Avinash on 4/7/10.
//  Copyright Apple Inc 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFOpenFlowView.h"

@interface CoverFlowViewController : UIViewController <AFOpenFlowViewDelegate,AFOpenFlowViewDataSource> {
	
// Queue to hold the cover flow images
	
	NSOperationQueue *loadImagesOperationQueue;

}


@end

