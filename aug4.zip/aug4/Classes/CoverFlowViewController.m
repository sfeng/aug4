//
//  CoverFlowViewController.m
//  CoverFlow
//
//  Created by Avinash on 4/7/10.
//  Copyright Apple Inc 2010. All rights reserved.
//  edited by sha sha 8/4/11: interfaceOrientation
//

#import "CoverFlowViewController.h"

@implementation CoverFlowViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	// loading images into the queue
	
	loadImagesOperationQueue = [[NSOperationQueue alloc] init];
		
	NSString *imageName;
	for (int i=0; i < 11; i++) {
		imageName = [[NSString alloc] initWithFormat:@"cover_%d.jpg", i];
		[(AFOpenFlowView *)self.view setImage:[UIImage imageNamed:imageName] forIndex:i];
		[imageName release];
		NSLog(@"%d is the index",i);
	
		
	}
	[(AFOpenFlowView *)self.view setNumberOfImages:11];
	
	
}




// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
	if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft)		
	{return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft);
	}
	else if(interfaceOrientation == UIInterfaceOrientationLandscapeRight)		
	{return (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
	}
	else
	{ return (interfaceOrientation == UIInterfaceOrientationPortrait);
	}

}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

- (void)openFlowView:(AFOpenFlowView *)openFlowView selectionDidChange:(int)index{
	
	
	NSLog(@"%d is selected",index);
	
}
- (void)openFlowView:(AFOpenFlowView *)openFlowView requestImageForIndex:(int)index{
}


- (UIImage *)defaultImage{
	
	return [UIImage imageNamed:@"cover_1.jpg"];
}

@end
